<div class="footer">
      <footer>
      <a class="fb-icon" href="https://www.facebook.com/" target="_blank">
         <i class="fab fa-facebook" ></i>
      </a>
      <a class="instagram-icon" href="https://www.instagram.com" target="_blank">
         <i class="fab fa-instagram"></i> 
      </a>
      <a class="twitter-icon" href="https://www.twitter.com" target="_blank">
         <i class="fab fa-twitter"></i>
      </a>
      </footer>

    </div>