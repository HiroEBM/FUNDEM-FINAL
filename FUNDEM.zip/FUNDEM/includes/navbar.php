<nav>
        <div class="logo">
        <img src="IMAGES/PLACEHOLDERS/LOGO.png" alt="leaf">
           FUNDEM
        </div>
  
        <input type="checkbox" id="click" />
        <label for="click" class="menu-btn">
          <i class="fas fa-bars"></i>
        </label>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="yourpost.php">Fundraiser</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="viewprofile.php">Profile</a></li>
          <li><a href="logout.php">Log Out</a></li>
        </ul>
      </nav>
